__attribute__((section(".text"))) 
void kernel_main() {
    // Endereço da memória de vídeo VGA
    unsigned char *video = (unsigned char*)0xa0000;

    // 1. Limpar a tela (pintar tudo de uma cor, ex: azul escuro)
    // 320 * 200 = 64.000 pixels
    for (int i = 0; i < 320 * 200; i++) {
        video[i] = 1; // Cor 1 costuma ser azul no padrão VGA
    }

    // 2. Desenhar um "pixel" ou um quadrado
    // Fórmula para achar a posição: y * largura + x
    int x = 160; // Centro horizontal
    int y = 100; // Centro vertical
    int cor = 14; // Amarelo
    
    video[y * 320 + x] = cor;

    // Desenhar uma linha simples
    for(int i = 0; i < 50; i++) {
        video[110 * 320 + (135 + i)] = 15; // Linha branca
    }

    while(1);
}
