[bits 16]
[org 0x7c00]

start:
    mov ax, 0x0013
    int 0x10
    ; Configura a memória inicial
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00

    ; 1. Lê o seu Kernel em C (que já está no setor 2 do arquivo)
    mov ah, 0x02
    mov al, 15          ; Lê 15 setores (pra garantir que pegou todo seu C)
    mov ch, 0
    mov dh, 0
    mov cl, 2           ; Começa no setor 2
    mov bx, 0x1000      ; Onde o C vai morar na RAM
    int 0x13

    ; 2. Ativa o Modo de 32 bits (GDT) para o C funcionar
    cli                 ; Desliga interrupções
    lgdt [gdt_descriptor]
    mov eax, cr0
    or eax, 1           ; Seta o bit de Modo Protegido
    mov cr0, eax

    jmp 0x08:init_32    ; Salto para o código de 32 bits

[bits 32]
init_32:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov esp, 0x90000    ; Define uma pilha segura

    call 0x1000         ; AGORA SIM: CHAMA O SEU KERNEL!
    jmp $

; Estrutura necessária para o processador aceitar 32 bits
gdt_start:
    dq 0x0
gdt_code:
    dw 0xffff, 0x0, 0x9a00, 0x00cf
gdt_data:
    dw 0xffff, 0x0, 0x9200, 0x00cf
gdt_end:
gdt_descriptor:
    dw gdt_end - gdt_start - 1
    dd gdt_start

times 510-($-$$) db 0
dw 0xaa55
