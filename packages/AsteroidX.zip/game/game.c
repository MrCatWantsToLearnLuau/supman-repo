#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <lua5.4/lua.h>
#include <lua5.4/lauxlib.h>
#include <lua5.4/lualib.h>
#include <dirent.h>
#include <stdio.h>
#include <string.h>

// --- ESTRUTURAS ---
typedef struct {
    char user[32];
    char pass[32];
} Auth;

typedef struct {
    char name[256];
    SDL_Rect rect;
    int is_hovered;
} MapCard;

// --- GLOBAIS ---
SDL_Window* win = NULL;
SDL_Renderer* ren = NULL;
TTF_Font* font = NULL;
TTF_Font* titleFont = NULL;

// --- FUNÇÕES AUXILIARES ---
void draw_text(const char* t, int x, int y, SDL_Color c, TTF_Font* f) {
    if (strlen(t) == 0) return;
    SDL_Surface* s = TTF_RenderText_Blended(f, t, c);
    SDL_Texture* tex = SDL_CreateTextureFromSurface(ren, s);
    SDL_Rect r = {x, y, s->w, s->h};
    SDL_RenderCopy(ren, tex, NULL, &r);
    SDL_FreeSurface(s);
    SDL_DestroyTexture(tex);
}

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();

    win = SDL_CreateWindow("AsteroidX", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1000, 600, 0);
    ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);
    font = TTF_OpenFont("xingling.ttf", 24);
    titleFont = TTF_OpenFont("xingling.ttf", 48);

    char user_in[32] = "", pass_in[32] = "";
    int authenticated = 0, focus = 0;
    char status_msg[64] = "INSIRA AS CREDENCIAIS";

    SDL_StartTextInput();

    while (1) {
        SDL_Event ev;
        while (SDL_PollEvent(&ev)) {
            if (ev.type == SDL_QUIT) return 0;
            
            if (!authenticated) {
                if (ev.type == SDL_TEXTINPUT) {
                    if (focus == 0 && strlen(user_in) < 31) strcat(user_in, ev.text.text);
                    else if (focus == 1 && strlen(pass_in) < 31) strcat(pass_in, ev.text.text);
                }
                if (ev.type == SDL_KEYDOWN) {
                    if (ev.key.keysym.sym == SDLK_BACKSPACE) {
                        if (focus == 0 && strlen(user_in) > 0) user_in[strlen(user_in)-1] = '\0';
                        else if (focus == 1 && strlen(pass_in) > 0) pass_in[strlen(pass_in)-1] = '\0';
                    }
                    if (ev.key.keysym.sym == SDLK_TAB) focus = !focus;
                    if (ev.key.keysym.sym == SDLK_RETURN) {
                        // Sistema de conta única simples para o Miguel
                        FILE *f = fopen("account.cfg", "rb");
                        if (!f) {
                            f = fopen("account.cfg", "wb");
                            Auth a; strcpy(a.user, user_in); strcpy(a.pass, pass_in);
                            fwrite(&a, sizeof(Auth), 1, f);
                            fclose(f);
                            strcpy(status_msg, "CONTA CRIADA! LOGUE AGORA.");
                        } else {
                            Auth a; fread(&a, sizeof(Auth), 1, f); fclose(f);
                            if (strcmp(a.user, user_in) == 0 && strcmp(a.pass, pass_in) == 0) {
                                authenticated = 1;
                                SDL_StopTextInput();
                            } else { strcpy(status_msg, "SENHA INCORRETA!"); }
                        }
                    }
                }
            }
        }

        SDL_SetRenderDrawColor(ren, 10, 10, 25, 255);
        SDL_RenderClear(ren);
        SDL_Color cyan = {0, 255, 255, 255}, white = {255, 255, 255, 255};

        if (!authenticated) {
            draw_text("ASTEROIDX ACCESS", 330, 50, cyan, titleFont);
            draw_text(status_msg, 380, 120, white, font);
            
            SDL_SetRenderDrawColor(ren, 30, 30, 50, 255);
            SDL_Rect r1 = {350, 200, 300, 45}, r2 = {350, 300, 300, 45};
            SDL_RenderFillRect(ren, &r1); SDL_RenderFillRect(ren, &r2);

            draw_text("USUARIO:", 350, 170, cyan, font);
            draw_text(user_in, 360, 208, white, font);
            draw_text("SENHA:", 350, 270, cyan, font);
            char stars[32] = ""; for(int i=0; i<strlen(pass_in); i++) strcat(stars, "*");
            draw_text(stars, 360, 308, white, font);
        } 
        else {
            // --- LOGICA DE MAPAS ---
            MapCard cards[10]; int map_count = 0;
            DIR *dr = opendir("maps");
            if (dr) {
                struct dirent *de;
                while ((de = readdir(dr)) != NULL && map_count < 10) {
                    if (strstr(de->d_name, ".lua")) {
                        strcpy(cards[map_count].name, de->d_name);
                        cards[map_count].rect = (SDL_Rect){250, 120 + (map_count * 70), 500, 60};
                        map_count++;
                    }
                }
                closedir(dr);
            }

            draw_text("AsteroidX Game Hub", 320, 40, cyan, titleFont);
            int mx, my; SDL_GetMouseState(&mx, &my);

            for (int i = 0; i < map_count; i++) {
                int hover = (mx > cards[i].rect.x && mx < cards[i].rect.x + cards[i].rect.w &&
                             my > cards[i].rect.y && my < cards[i].rect.y + cards[i].rect.h);
                
                SDL_SetRenderDrawColor(ren, hover ? 0 : 30, hover ? 200 : 30, hover ? 180 : 45, 255);
                SDL_RenderFillRect(ren, &cards[i].rect);
                draw_text(cards[i].name, cards[i].rect.x + 20, cards[i].rect.y + 15, white, font);

                if (hover && SDL_GetMouseState(NULL, NULL) & SDL_BUTTON(SDL_BUTTON_LEFT)) {
                    char path[300]; sprintf(path, "maps/%s", cards[i].name);
                    SDL_HideWindow(win);
                    
                    lua_State *L = luaL_newstate();
                    luaL_openlibs(L);
                    luaL_dostring(L, "package.path = package.path .. ';./maps/?.lua'");
                    luaL_dostring(L, "package.cpath = package.cpath .. ';./maps/?.so'");
                    
                    if (luaL_dofile(L, path) != LUA_OK) printf("ERRO: %s\n", lua_tostring(L, -1));
                    lua_close(L);
                    
                    SDL_ShowWindow(win);
                    SDL_SetRelativeMouseMode(SDL_FALSE);
                }
            }
        }
        SDL_RenderPresent(ren);
        SDL_Delay(16);
    }
    return 0;
}
