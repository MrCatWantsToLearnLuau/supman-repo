local ast = require("ast")

-- 1. Configuração Inicial
ast.init(1000, 600, "Asteroids 3D: Zombie Survival v1.3")
ast.lockMouse(true)

-- 2. Estado do Personagem
local player = {
    x = 0, y = 1.0, z = 0,
    w = 1.0, h = 2.0, d = 1.0,
    velY = 0,
    speed = 12.0,
    isAlive = true
}

local gravity = -25.0
local jumpForce = 10.0

-- 3. Inimigo e Mapa (AABB)
local zombie = { x = 15, y = 1, z = -15, speed = 4.8 }

-- {x, y, z, larg, alt, prof}
local obstacles = {
    { -10, 2, -10, 4, 4, 4 }, -- Caixa Cinza
    { 15, 3, 5, 2, 6, 2 }     -- Pilar Marrom
}

-- 4. Câmera e Menu
local cam = { dist = 14.0, pitch = 35.0, yaw = -90.0, sensitivity = 0.25 }
local menuOpen = false

-- --- FUNÇÕES DE MATEMÁTICA ---

-- Colisão AABB (Para as caixas)
function checkAABB(p, b)
    return (p.x + p.w/2 > b[1] - b[4]/2 and p.x - p.w/2 < b[1] + b[4]/2) and
           (p.z + p.d/2 > b[3] - b[6]/2 and p.z - p.d/2 < b[3] + b[6]/2) and
           (p.y < b[2] + b[5]/2 and p.y + p.h > b[2] - b[5]/2)
end

-- --- LOOP PRINCIPAL ---
while ast.isOpen() do
    local dt = ast.getDeltaTime()

    if ast.isKeyDown("Escape") then
        menuOpen = not menuOpen
        ast.lockMouse(not menuOpen)
        ast.wait(200) 
    end

    if menuOpen then
        -- MENU CORRIGIDO (Texto centralizado e visível)
        ast.clear(10, 10, 25)
        ast.setCamera(0, 5, 15, 0, 5, 0) -- Afastei a câmera do painel
        ast.createBox(0, 5, 0, 10, 8, 0.1, 40, 40, 60)
        
        ast.drawText("MENU DE PAUSA", 420, 150)
        ast.drawText("[R] RECOMEÇAR POSIÇÃO", 380, 250)
        ast.drawText("[L] SAIR DO JOGO", 415, 310) -- Agora aparece!

        if ast.isKeyDown("R") then 
            player.x, player.z = 0, 0
            menuOpen = false
            ast.lockMouse(true)
        end
        if ast.isKeyDown("L") then break end

    elseif not player.isAlive then
        ast.clear(40, 0, 0)
        ast.drawText("VOCÊ FOI PEGO!", 420, 250)
        ast.drawText("Pressione R para Renascer", 380, 310)
        if ast.isKeyDown("R") then 
            player.x, player.z, player.isAlive = 0, 0, true 
            zombie.x, zombie.z = 15, -15
        end
    else
        -- JOGO ATIVO
        ast.clear(135, 206, 235)

        -- A. Câmera
        local dx, dy = ast.getMouseDelta()
        cam.yaw = cam.yaw + (dx * cam.sensitivity)
        cam.pitch = cam.pitch - (dy * cam.sensitivity)
        if cam.pitch > 85 then cam.pitch = 85 end
        if cam.pitch < 5 then cam.pitch = 5 end

        local pRad, yRad = math.rad(cam.pitch), math.rad(cam.yaw)
        local camX = player.x + cam.dist * math.cos(pRad) * math.cos(yRad)
        local camY = player.y + cam.dist * math.sin(pRad)
        local camZ = player.z + cam.dist * math.cos(pRad) * math.sin(yRad)
        ast.setCamera(camX, camY, camZ, player.x, player.y, player.z)

        -- B. Movimentação (A e D CORRIGIDOS)
        local lookX, lookZ = math.cos(yRad), math.sin(yRad)
        local rightX, rightZ = -math.sin(yRad), math.cos(yRad)

        local oldX, oldZ = player.x, player.z -- Salva posição para colisão

        if ast.isKeyDown("W") then
            player.x = player.x - lookX * player.speed * dt
            player.z = player.z - lookZ * player.speed * dt
        end
        if ast.isKeyDown("S") then
            player.x = player.x + lookX * player.speed * dt
            player.z = player.z + lookZ * player.speed * dt
        end
        -- Inverti os sinais aqui para arrumar o A e D:
        if ast.isKeyDown("A") then
            player.x = player.x + rightX * player.speed * dt
            player.z = player.z + rightZ * player.speed * dt
        end
        if ast.isKeyDown("D") then
            player.x = player.x - rightX * player.speed * dt
            player.z = player.z - rightZ * player.speed * dt
        end

        -- C. Colisão com Obstáculos (Parede Sólida)
        for _, b in ipairs(obstacles) do
            if checkAABB(player, b) then
                player.x = oldX
                player.z = oldZ
            end
        end

        -- D. Gravidade e Pulo
        player.velY = player.velY + gravity * dt
        player.y = player.y + player.velY * dt
        if player.y < 1.0 then 
            player.y = 1.0 
            player.velY = 0
            if ast.isKeyDown("Space") then player.velY = jumpForce end
        end

        -- E. IA do Zumbi
        local dZ_X = player.x - zombie.x
        local dZ_Z = player.z - zombie.z
        local dist = math.sqrt(dZ_X^2 + dZ_Z^2)
        if dist > 1.2 then
            zombie.x = zombie.x + (dZ_X / dist) * zombie.speed * dt
            zombie.z = zombie.z + (dZ_Z / dist) * zombie.speed * dt
        else
            player.isAlive = false
        end

        -- F. Renderização
        ast.createBox(0, -0.1, 0, 100, 0.2, 100, 50, 50, 50) -- Chão
        ast.createBox(player.x, player.y, player.z, 1, 2, 1, 255, 255, 0) -- Player
        ast.createBox(zombie.x, zombie.y, zombie.z, 1, 2, 1, 0, 160, 0) -- Zumbi
        
        -- Desenha as Caixas
        ast.createBox(obstacles[1][1], obstacles[1][2], obstacles[1][3], obstacles[1][4], obstacles[1][5], obstacles[1][6], 100, 100, 120)
        ast.createBox(obstacles[2][1], obstacles[2][2], obstacles[2][3], obstacles[2][4], obstacles[2][5], obstacles[2][6], 80, 50, 30)

        ast.drawText("ZUMBIS: 1", 20, 20)
    end

    ast.display()
    ast.wait(16)
end
ast.quit()
