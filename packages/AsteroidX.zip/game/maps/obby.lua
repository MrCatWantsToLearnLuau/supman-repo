local ast = require("ast")

-- 1. Inicialização do Motor
ast.init(1000, 600, "Asteroids 3D: Mega Obby Final")
ast.lockMouse(true)

-- 2. Estado do Player (Física AABB)
local player = {
    x = 0, y = 5, z = 0,
    w = 0.8, h = 2.0, d = 0.8,
    velY = 0,
    speed = 14.0,   -- Velocidade ajustada para dt
    jumpForce = 13.0,
    isGrounded = false
}

local gravity = 30.0
local cam = { yaw = -90, pitch = 30, dist = 15 }
local menuOpen = false

-- 3. Mapa do Obby (Tabela de Blocos)
-- Formato: {x, y, z, larg, alt, prof, r, g, b}
local map = {
    {0, 0, 0, 8, 0.5, 8, 100, 100, 255},      -- Spawn (Azul)
    {0, 3, -12, 4, 0.5, 4, 255, 100, 100},    -- Pulo 1 (Vermelho)
    {6, 6, -20, 4, 0.5, 4, 100, 255, 100},    -- Pulo 2 (Verde)
    {-6, 9, -30, 5, 0.5, 5, 255, 255, 100},   -- Pulo 3 (Amarelo)
    {0, 12, -45, 12, 1, 12, 255, 255, 255},   -- Chegada (Branco)
    {0, -5, -25, 50, 0.2, 100, 30, 30, 30}    -- "Chão de Lava" (Cinza)
}

-- 4. Função de Colisão AABB
function checkAABB(p, b)
    return (p.x + p.w/2 > b[1] - b[4]/2 and p.x - p.w/2 < b[1] + b[4]/2) and
           (p.y > b[2] + b[5]/2 - 0.6 and p.y < b[2] + b[5]/2 + 0.6) and
           (p.z + p.d/2 > b[3] - b[6]/2 and p.z - p.d/2 < b[3] + b[6]/2)
end

-- --- LOOP PRINCIPAL ---
while ast.isOpen() do
    local dt = ast.getDeltaTime()

    -- Alternar Menu (ESC)
    if ast.isKeyDown("Escape") then
        menuOpen = not menuOpen
        ast.lockMouse(not menuOpen)
        ast.wait(200)
    end

    if menuOpen then
        -- LÓGICA DO MENU
        ast.clear(15, 15, 35)
        ast.setCamera(0, 5, 10, 0, 5, 0)
        ast.createBox(0, 5, 0, 8, 10, 0.1, 40, 40, 60) -- Painel
        ast.drawText("MENU PAUSA", 430, 150)
        ast.drawText("[R] REINICIAR", 415, 250)
        ast.drawText("[L] SAIR", 445, 300)

        if ast.isKeyDown("R") then
            player.x, player.y, player.z = 0, 5, 0
            player.velY = 0
            menuOpen = false
            ast.lockMouse(true)
        end
        if ast.isKeyDown("L") then break end
    else
        -- LÓGICA DO JOGO
        ast.clear(50, 50, 85) -- Céu escuro

        -- A. Mouse e Câmera
        local dx, dy = ast.getMouseDelta()
        cam.yaw = cam.yaw + (dx * 0.25)
        cam.pitch = cam.pitch - (dy * 0.25)
        if cam.pitch > 85 then cam.pitch = 85 end
        if cam.pitch < 5 then cam.pitch = 5 end

        local pRad, yRad = math.rad(cam.pitch), math.rad(cam.yaw)
        local camX = player.x + cam.dist * math.cos(pRad) * math.cos(yRad)
        local camY = player.y + cam.dist * math.sin(pRad)
        local camZ = player.z + cam.dist * math.cos(pRad) * math.sin(yRad)
        ast.setCamera(camX, camY, camZ, player.x, player.y, player.z)

        -- B. Movimentação WASD
        local lookX = math.cos(yRad)
        local lookZ = math.sin(yRad)
        local rightX = -math.sin(yRad)
        local rightZ = math.cos(yRad)

        if ast.isKeyDown("W") then
            player.x = player.x - lookX * player.speed * dt
            player.z = player.z - lookZ * player.speed * dt
        end
        if ast.isKeyDown("S") then
            player.x = player.x + lookX * player.speed * dt
            player.z = player.z + lookZ * player.speed * dt
        end
        if ast.isKeyDown("A") then
            player.x = player.x + rightX * player.speed * dt
            player.z = player.z + rightZ * player.speed * dt
        end
        if ast.isKeyDown("D") then
            player.x = player.x - rightX * player.speed * dt
            player.z = player.z - rightZ * player.speed * dt
        end

        -- C. Física e Gravidade
        player.velY = player.velY - (gravity * dt)
        player.y = player.y + (player.velY * dt)

        -- D. Colisão com o Mapa
        player.isGrounded = false
        for _, b in ipairs(map) do
            ast.createBox(b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9])
            
            if player.velY <= 0 and checkAABB(player, b) then
                player.y = b[2] + b[5]/2 + 0.1
                player.velY = 0
                player.isGrounded = true
            end
        end

        -- Pulo
        if player.isGrounded and ast.isKeyDown("Space") then
            player.velY = player.jumpForce
        end

        -- Morte por Queda
        if player.y < -20 then
            player.x, player.y, player.z = 0, 5, 0
            player.velY = 0
        end

        -- E. Render Player e UI
        ast.createBox(player.x, player.y + 1, player.z, 1, 2, 1, 255, 255, 0)
        ast.drawText("MEGA OBBY - Miguel & Valdemar", 20, 20)
        ast.drawText("FPS: " .. math.floor(1/dt), 20, 50)
    end

    ast.display()
    ast.wait(16)
end

ast.quit()
