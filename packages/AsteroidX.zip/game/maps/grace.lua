local ast = require("ast")

-- 1. Inicialização do Client
ast.init(1000, 600, "GRACE: Loss of Connection")
ast.lockMouse(true)

-- Carregar Recursos
local spr_carnation = ast.loadImage("maps/wer.png")
local spr_doombringer = ast.loadImage("maps/joey.png")

-- Estado Global
local client = { running = true, paused = false, gameOver = false, timer = 150 }
local player = { x = 0, y = 1.8, z = 0, speed = 15.0, yaw = -90, pitch = 0 }

-- Wer (Carnation) - Aumentei o spawn para 120 de distância
local carnation = { z = 0, active = false, triggered = false, speed = 88.0 }

while ast.isOpen() and client.running do
    local dt = ast.getDeltaTime()

    if ast.isKeyDown("Escape") then
        client.paused = not client.paused
        ast.lockMouse(not client.paused)
        ast.wait(200)
    end

    if client.paused then
        ast.clear(5, 5, 15)
        ast.drawText("MENU PAUSA", 450, 200)
        if ast.isKeyDown("Q") then client.running = false end
    elseif client.gameOver then
        ast.clear(100, 0, 0)
        ast.drawText("CONEXÃO PERDIDA", 410, 300)
        if ast.isKeyDown("R") then -- Reiniciar
            player.z = 0
            client.gameOver = false
            carnation.triggered = false
            carnation.active = false
        end
    else
        ast.clear(2, 2, 8)

        -- 1. Câmera
        local dx, dy = ast.getMouseDelta()
        player.yaw = player.yaw + (dx * 0.2)
        player.pitch = player.pitch - (dy * 0.2)
        if player.pitch > 85 then player.pitch = 85 end
        if player.pitch < -85 then player.pitch = -85 end

        local yRad = math.rad(player.yaw)
        local pRad = math.rad(player.pitch)
        local lookX = math.cos(yRad) * math.cos(pRad)
        local lookY = math.sin(pRad)
        local lookZ = math.sin(yRad) * math.cos(pRad)
        ast.setCamera(player.x, player.y, player.z, player.x + lookX, player.y + lookY, player.z + lookZ)

        -- 2. Movimentação (W e S)
        local moveSpeed = player.speed
        if ast.isKeyDown("Left Shift") then
            player.y = 1.0 
            moveSpeed = player.speed * 2.5 -- Slide mais rápido
        else
            player.y = 1.8
        end

        if ast.isKeyDown("W") then player.z = player.z + lookZ * moveSpeed * dt end
        if ast.isKeyDown("S") then player.z = player.z - lookZ * moveSpeed * dt end

        -- 3. Cenário com "Marcas de Sala" (Para sentir o movimento)
        for i = -2, 10 do -- Renderiza salas à frente e atrás
            local roomZ = (math.floor(player.z / 30) + i) * 30
            -- Paredes e divisórias
            ast.createBox(7, 3, roomZ, 0.2, 6, 30, 40, 40, 50)
            ast.createBox(-7, 3, roomZ, 0.2, 6, 30, 40, 40, 50)
            -- Linha no chão para marcar que você passou de sala
            ast.createBox(0, 0.1, roomZ, 14, 0.1, 0.5, 100, 100, 255) 
        end
        ast.createBox(0, 0, player.z, 15, 0.2, 400, 20, 20, 25) -- Chão contínuo
        ast.createBox(0, 6, player.z, 15, 0.2, 400, 10, 10, 15) -- Teto

        -- 4. IA do Wer (Carnation) corrigida
        if math.abs(player.z) > 120 and not carnation.triggered then
            carnation.active = true
            carnation.triggered = true
            carnation.z = player.z - 100 -- Surge bem atrás para dar medo
        end

        if carnation.active then
            carnation.z = carnation.z + (carnation.speed * dt)
            local dist = math.abs(carnation.z - player.z)
            
            if dist < 40 then
                local size = 700 - (dist * 15)
                ast.drawImageScaled(0, spr_carnation, 500 - (size/2), 300 - (size/2), size, size)
            end

            -- Colisão: Se não estiver no slide (Shift), morre
            if dist < 2.5 then
                if player.y > 1.2 then
                    client.gameOver = true
                else
                    -- Escapou por baixo (Wer some ao passar)
                    if carnation.z > player.z + 5 then carnation.active = false end
                end
            end
        end

        -- UI
        ast.drawText("SALA: " .. math.floor(math.abs(player.z/30)), 20, 20)
        ast.drawText("DISTANCIA DO SINAL: " .. math.floor(math.abs(player.z)), 20, 60)
    end

    ast.display()
    ast.wait(16)
end
ast.quit()
