local ast = require("ast")

-- Configurações iniciais
local LARGURA, ALTURA = 1000, 600
ast.init(LARGURA, ALTURA, "Meu Pet Virtual 3D")
ast.lockMouse(false)

-- Status do Pet
local pet = {
    fome = 100,
    felicidade = 100,
    energia = 100,
    tamanho = 1.0,
    cor = {r = 200, g = 150, b = 255}, -- Um pet roxinho
    rotacao = 0
}

-- Carregar imagem de fundo ou ícones se quiser
-- local imgFundo = ast.loadImage("fundo.png")

local function desenharInterface()
    -- Barra de Fome
    ast.drawText("FOME: " .. math.floor(pet.fome), 20, 20)
    ast.drawCircle(150, 35, 10, 16, 255, 0, 0) -- Ícone vermelho

    -- Barra de Felicidade
    ast.drawText("FELIZ: " .. math.floor(pet.felicidade), 20, 60)
    ast.drawCircle(150, 75, 10, 16, 255, 255, 0) -- Ícone amarelo

    -- Instruções
    ast.drawText("[1] Alimentar  [2] Brincar  [3] Dormir", 300, 550)
end

while ast.isOpen() do
    local dt = ast.getDeltaTime()
    
    -- Diminuir status com o tempo
    pet.fome = math.max(0, pet.fome - 2 * dt)
    pet.felicidade = math.max(0, pet.felicidade - 1.5 * dt)
    pet.energia = math.max(0, pet.energia - 1 * dt)

    -- Lógica de Inputs
    if ast.isKeyDown("1") and pet.fome < 100 then
        pet.fome = pet.fome + 10 * dt
        pet.tamanho = pet.tamanho + 0.01 * dt -- Pet cresce se comer muito
    end
    if ast.isKeyDown("2") and pet.felicidade < 100 then
        pet.felicidade = pet.felicidade + 15 * dt
        pet.rotacao = pet.rotacao + 200 * dt -- Pet pula/gira de alegria
    end
    if ast.isKeyDown("Escape") then
        break
    end

    -- Limpar tela (Azul céu)
    ast.clear(100, 150, 255)

    -- Configurar Câmera 3D
    -- Olhando para o centro (0,0,0) de uma posição elevada
    ast.setCamera(0, 5, 10, 0, 0, 0)

    -- Desenhar o Chão (Um cubo bem achatado)
    ast.createBox(0, -1, 0, 20, 0.1, 20, 50, 150, 50)

    -- Desenhar o Pet (O cubo principal)
    -- Ele flutua um pouco se estiver feliz
    local pulo = math.sin(ast.getDeltaTime() * 10) * (pet.felicidade / 100)
    ast.createBox(0, 0.5 + pulo, 0, pet.tamanho, pet.tamanho, pet.tamanho, pet.cor.r, pet.cor.g, pet.cor.b)

    -- Desenhar a Interface (2D por cima do 3D)
    desenharInterface()

    ast.display()
    ast.wait(10) -- Poupar o seu i3 de fritar
end

ast.quit()
