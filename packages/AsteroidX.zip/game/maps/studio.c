#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[64];
    char className[32];
    int parent;
    int level;
    // Propriedades reais
    float px, py, pz;
    float sx, sy, sz;
    int r, g, b;
} Instance;

Instance tree[500];
int total_objs = 0;
int selected = -1;
TTF_Font* font = NULL;

char input_buffer[64] = "";
int is_typing = 0;

void add_inst(const char* name, const char* class, int p_id) {
    if (total_objs >= 500) return;
    strncpy(tree[total_objs].name, name, 64);
    strncpy(tree[total_objs].className, class, 32);
    tree[total_objs].parent = p_id;
    tree[total_objs].level = (p_id != -1) ? tree[p_id].level + 1 : 0;
    
    // Valores padrão (Baseplate style)
    tree[total_objs].px = 0; tree[total_objs].py = 0; tree[total_objs].pz = 0;
    tree[total_objs].sx = 1; tree[total_objs].sy = 1; tree[total_objs].sz = 1;
    tree[total_objs].r = 163; tree[total_objs].g = 162; tree[total_objs].b = 165;
    
    selected = total_objs;
    total_objs++;
}

void export_and_play() {
    system("mkdir -p maps");
    FILE *f = fopen("maps/projeto.lua", "w");
    if (!f) return;
    
    fprintf(f, "-- AsteroidX Project\nlocal ast = require('asteroids')\nast.createWindow(1000, 600, 'Game View')\n\n");
    fprintf(f, "while ast.isOpen() do\n  ast.clear(0, 35, 35, 35)\n");
    
    for (int i = 0; i < total_objs; i++) {
        if (strcmp(tree[i].className, "Part") == 0) {
            // Exporta a part com suas propriedades reais
            fprintf(f, "  ast.drawSquare(0, %d, %d, %d, %d, %d, %d) -- %s\n", 
                    (int)(tree[i].px + 400), (int)(tree[i].py + 300), (int)(tree[i].sx * 50),
                    tree[i].r, tree[i].g, tree[i].b, tree[i].name);
        }
    }
    
    fprintf(f, "  ast.display(0)\nend\nast.quit()\n");
    fclose(f);
    system("lua maps/projeto.lua &");
}

void draw_text(SDL_Renderer* res, const char* text, int x, int y, SDL_Color col) {
    if (!font || !text[0]) return;
    SDL_Surface* s = TTF_RenderText_Blended(font, text, col);
    SDL_Texture* t = SDL_CreateTextureFromSurface(res, s);
    SDL_Rect d = {x, y, s->w, s->h};
    SDL_RenderCopy(res, t, NULL, &d);
    SDL_FreeSurface(s); SDL_DestroyTexture(t);
}

int main() {
    SDL_Init(SDL_INIT_VIDEO); TTF_Init();
    font = TTF_OpenFont("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf", 14);
    
    SDL_Window* win = SDL_CreateWindow("Minux 1.0 - AsteroidX Studio", 100, 100, 1100, 700, 0);
    SDL_Renderer* res = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);

    // Estrutura de Instâncias Nativas
    add_inst("Workspace", "Workspace", -1);
    add_inst("Players", "Players", -1);
    add_inst("Lighting", "Lighting", -1);
    add_inst("ReplicatedStorage", "ReplicatedStorage", -1);
    add_inst("StarterGui", "StarterGui", -1);

    int running = 1; SDL_Event ev;
    SDL_StartTextInput();

    while (running) {
        while (SDL_PollEvent(&ev)) {
            if (ev.type == SDL_QUIT) running = 0;
            
            if (is_typing) {
                if (ev.type == SDL_TEXTINPUT) strcat(input_buffer, ev.text.text);
                if (ev.type == SDL_KEYDOWN) {
                    if (ev.key.keysym.sym == SDLK_BACKSPACE && strlen(input_buffer) > 0) 
                        input_buffer[strlen(input_buffer)-1] = '\0';
                    if (ev.key.keysym.sym == SDLK_RETURN) {
                        add_inst(input_buffer, "Part", selected);
                        input_buffer[0] = '\0'; is_typing = 0;
                    }
                }
            } else {
                if (ev.type == SDL_MOUSEBUTTONDOWN) {
                    if (ev.button.button == SDL_BUTTON_RIGHT) is_typing = 1;
                    if (ev.button.x > 850) {
                        int id = (ev.button.y - 40) / 24;
                        if (id >= 0 && id < total_objs) selected = id;
                    }
                }
                if (ev.type == SDL_KEYDOWN && ev.key.keysym.sym == SDLK_F5) export_and_play();
            }
        }

        SDL_SetRenderDrawColor(res, 45, 44, 48, 255); SDL_RenderClear(res);
        
        // Explorer
        SDL_SetRenderDrawColor(res, 37, 37, 38, 255);
        SDL_Rect side = {850, 0, 250, 700}; SDL_RenderFillRect(res, &side);
        
        SDL_Color w = {255, 255, 255, 255};
        draw_text(res, "EXPLORER (F5: Run | RC: Add Part)", 855, 10, w);

        for (int i = 0; i < total_objs; i++) {
            if (i == selected) {
                SDL_SetRenderDrawColor(res, 0, 120, 215, 255);
                SDL_Rect r_sel = {850, 40 + (i * 24), 250, 24}; 
                SDL_RenderFillRect(res, &r_sel); // CORRIGIDO AQUI
            }
            char display[128];
            sprintf(display, "%s (%s)", tree[i].name, tree[i].className);
            draw_text(res, display, 860 + (tree[i].level * 15), 42 + (i * 24), w);
        }

        if (is_typing) {
            SDL_SetRenderDrawColor(res, 20, 20, 20, 220);
            SDL_Rect bar = {0, 660, 850, 40}; SDL_RenderFillRect(res, &bar);
            draw_text(res, "Instance Name:", 10, 670, (SDL_Color){255, 255, 0, 255});
            draw_text(res, input_buffer, 130, 670, w);
        }

        SDL_RenderPresent(res);
    }
    
    SDL_StopTextInput();
    TTF_Quit(); SDL_Quit(); return 0;
}
