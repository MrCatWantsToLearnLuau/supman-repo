-- AsteroidX Project
local ast = require('ast')
ast.init(1000, 600, 'Game View')
local px, py, pz, pw, ph = 100, 100, 10, 67, 41

while ast.isOpen() do
  if ast.isKeyDown("Escape") then break end
  ast.clear(0, 35, 35, 35)
  ast.createBox(px, py, pz, pw, ph) -- Script
  ast.display()
  ast.wait(16)
end
ast.quit()
