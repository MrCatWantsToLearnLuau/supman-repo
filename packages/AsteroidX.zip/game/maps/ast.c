#include <GL/gl.h>
#include <GL/glu.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h> // Adicionado para carregar wer.png e joey.png
#include <lua5.4/lua.h>
#include <lua5.4/lauxlib.h>
#include <lua5.4/lualib.h>
#include <stdio.h>
#include <string.h>

SDL_Window* window = NULL;
SDL_GLContext glContext;
TTF_Font* gameFont = NULL;
Uint32 last_frame_time = 0; // Para o DeltaTime do Client

// --- INICIALIZAÇÃO ---
int l_init(lua_State *L) {
    int w = luaL_checkinteger(L, 1);
    int h = luaL_checkinteger(L, 2);
    const char* title = luaL_optstring(L, 3, "Asteroids Engine 3D");

    if (SDL_Init(SDL_INIT_VIDEO) < 0) return luaL_error(L, "Erro SDL");
    if (TTF_Init() < 0) return luaL_error(L, "Erro TTF");
    IMG_Init(IMG_INIT_PNG); // Inicia suporte a imagens

    window = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, w, h, SDL_WINDOW_OPENGL);
    glContext = SDL_GL_CreateContext(window);

    glEnable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double)w/h, 0.1, 1000.0);
    glMatrixMode(GL_MODELVIEW);

    gameFont = TTF_OpenFont("xingling.ttf", 24);
    last_frame_time = SDL_GetTicks();
    
    return 0;
}

// --- IMAGENS (WER E JOEY) ---
int l_loadImage(lua_State *L) {
    const char* path = luaL_checkstring(L, 1);
    SDL_Surface* surf = IMG_Load(path);
    if (!surf) return luaL_error(L, "Erro ao carregar imagem: %s", path);

    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    
    int mode = (surf->format->BytesPerPixel == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, mode, surf->w, surf->h, 0, mode, GL_UNSIGNED_BYTE, surf->pixels);
    
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    SDL_FreeSurface(surf);
    lua_pushinteger(L, tex);
    return 1;
}

int l_drawImageScaled(lua_State *L) {
    int id = luaL_checkinteger(L, 1); // No seu Lua voce usa 0 como id as vezes, mas aqui pegamos o ID da textura
    int tex = luaL_checkinteger(L, 2);
    float x = luaL_checknumber(L, 3), y = luaL_checknumber(L, 4);
    float w = luaL_checknumber(L, 5), h = luaL_checknumber(L, 6);

    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, tex);
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glMatrixMode(GL_PROJECTION); glPushMatrix(); glLoadIdentity();
    glOrtho(0, 1000, 600, 0, -1, 1);
    glMatrixMode(GL_MODELVIEW); glPushMatrix(); glLoadIdentity();

    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
        glTexCoord2f(0,0); glVertex2f(x, y);
        glTexCoord2f(1,0); glVertex2f(x+w, y);
        glTexCoord2f(1,1); glVertex2f(x+w, y+h);
        glTexCoord2f(0,1); glVertex2f(x, y+h);
    glEnd();

    glPopMatrix(); glMatrixMode(GL_PROJECTION); glPopMatrix();
    glPopAttrib();
    return 0;
}

// --- DESENHO 3D (CUBOS) ---
int l_createBox(lua_State *L) {
    float x = (float)luaL_checknumber(L, 1), y = (float)luaL_checknumber(L, 2), z = (float)luaL_checknumber(L, 3);
    float w = (float)luaL_checknumber(L, 4) / 2.0f, h = (float)luaL_checknumber(L, 5) / 2.0f, d = (float)luaL_checknumber(L, 6) / 2.0f;
    int r = luaL_optinteger(L, 7, 255), g = luaL_optinteger(L, 8, 255), b = luaL_optinteger(L, 9, 255);

    glColor3ub(r, g, b);
    glBegin(GL_QUADS);
        glVertex3f(x-w, y-h, z+d); glVertex3f(x+w, y-h, z+d); glVertex3f(x+w, y+h, z+d); glVertex3f(x-w, y+h, z+d);
        glVertex3f(x-w, y-h, z-d); glVertex3f(x-w, y+h, z-d); glVertex3f(x+w, y+h, z-d); glVertex3f(x+w, y-h, z-d);
        glVertex3f(x-w, y+h, z-d); glVertex3f(x-w, y+h, z+d); glVertex3f(x+w, y+h, z+d); glVertex3f(x+w, y+h, z-d);
        glVertex3f(x-w, y-h, z-d); glVertex3f(x+w, y-h, z-d); glVertex3f(x+w, y-h, z+d); glVertex3f(x-w, y-h, z+d);
        glVertex3f(x-w, y-h, z-d); glVertex3f(x-w, y-h, z+d); glVertex3f(x-w, y+h, z+d); glVertex3f(x-w, y+h, z-d);
        glVertex3f(x+w, y-h, z-d); glVertex3f(x+w, y+h, z-d); glVertex3f(x+w, y+h, z+d); glVertex3f(x+w, y-h, z+d);
    glEnd();
    return 0;
}

// --- TEXTO (SEU CODIGO OTIMIZADO) ---
int l_drawText(lua_State *L) {
    const char* text = luaL_checkstring(L, 1);
    int x = luaL_checkinteger(L, 2), y = luaL_checkinteger(L, 3);
    if (!gameFont || !text || strlen(text) == 0) return 0;

    SDL_Color color = {255, 255, 255, 255};
    SDL_Surface* surf = TTF_RenderText_Blended(gameFont, text, color);
    if (!surf) return 0;

    SDL_Surface* optimized = SDL_CreateRGBSurfaceWithFormat(0, surf->w, surf->h, 32, SDL_PIXELFORMAT_RGBA32);
    SDL_BlitSurface(surf, NULL, optimized, NULL);

    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
    glPixelStorei(GL_UNPACK_ROW_LENGTH, optimized->pitch / 4);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, optimized->w, optimized->h, 0, GL_RGBA, GL_UNSIGNED_BYTE, optimized->pixels);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_TEXTURE_2D); glDisable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION); glPushMatrix(); glLoadIdentity(); glOrtho(0, 1000, 600, 0, -1, 1);
    glMatrixMode(GL_MODELVIEW); glPushMatrix(); glLoadIdentity();

    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
        glTexCoord2f(0,0); glVertex2f(x, y);
        glTexCoord2f(1,0); glVertex2f(x + optimized->w, y);
        glTexCoord2f(1,1); glVertex2f(x + optimized->w, y + optimized->h);
        glTexCoord2f(0,1); glVertex2f(x, y + optimized->h);
    glEnd();

    glPopMatrix(); glMatrixMode(GL_PROJECTION); glPopMatrix();
    glPopAttrib();

    glDeleteTextures(1, &texture);
    SDL_FreeSurface(surf);
    SDL_FreeSurface(optimized);
    glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
    return 0;
}

// --- CLIENT & TEMPO ---
int l_getDeltaTime(lua_State *L) {
    Uint32 current = SDL_GetTicks();
    float dt = (current - last_frame_time) / 1000.0f;
    last_frame_time = current;
    lua_pushnumber(L, dt);
    return 1;
}

// --- INPUTS & CAMERA ---
int l_setCamera(lua_State *L) {
    glLoadIdentity();
    gluLookAt(luaL_checknumber(L, 1), luaL_checknumber(L, 2), luaL_checknumber(L, 3),
              luaL_checknumber(L, 4), luaL_checknumber(L, 5), luaL_checknumber(L, 6), 0, 1, 0);
    return 0;
}

int l_lockMouse(lua_State *L) { SDL_SetRelativeMouseMode(lua_toboolean(L, 1)); return 0; }
int l_getMouseDelta(lua_State *L) {
    int x, y; SDL_GetRelativeMouseState(&x, &y);
    lua_pushnumber(L, (float)x); lua_pushnumber(L, (float)y);
    return 2;
}

int l_isKeyDown(lua_State *L) {
    const Uint8* state = SDL_GetKeyboardState(NULL);
    lua_pushboolean(L, state[SDL_GetScancodeFromName(luaL_checkstring(L, 1))]);
    return 1;
}

// --- UTILITÁRIOS ---
int l_clear(lua_State *L) {
    glClearColor(luaL_optnumber(L, 1, 0)/255.f, luaL_optnumber(L, 2, 0)/255.f, luaL_optnumber(L, 3, 0)/255.f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    return 0;
}

int l_isOpen(lua_State *L) {
    SDL_Event ev;
    while(SDL_PollEvent(&ev)) if(ev.type == SDL_QUIT) { lua_pushboolean(L, 0); return 1; }
    lua_pushboolean(L, 1); return 1;
}

int l_display(lua_State *L) { SDL_GL_SwapWindow(window); return 0; }
int l_wait(lua_State *L) { SDL_Delay(luaL_checkinteger(L, 1)); return 0; }

int l_quit(lua_State *L) {
    if (glContext) SDL_GL_DeleteContext(glContext);
    if (window) SDL_DestroyWindow(window); 
    return 0;
}
// --- DESENHO DE CÍRCULO (2D/HUD) ---
int l_drawCircle(lua_State *L) {
    float cx = (float)luaL_checknumber(L, 1); // Posição X na tela
    float cy = (float)luaL_checknumber(L, 2); // Posição Y na tela
    float r = (float)luaL_checknumber(L, 3);  // Raio
    int segments = (int)luaL_optinteger(L, 4, 32); // Qualidade (lados)
    int red = luaL_optinteger(L, 5, 255), green = luaL_optinteger(L, 6, 255), blue = luaL_optinteger(L, 7, 255);

    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_DEPTH_TEST); // Para desenhar por cima do 3D
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Muda para modo 2D temporariamente
    glMatrixMode(GL_PROJECTION); glPushMatrix(); glLoadIdentity();
    glOrtho(0, 1000, 600, 0, -1, 1); // Mesma escala que você usou no drawText
    glMatrixMode(GL_MODELVIEW); glPushMatrix(); glLoadIdentity();

    glColor3ub(red, green, blue);
    glBegin(GL_TRIANGLE_FAN);
        glVertex2f(cx, cy); // Ponto central
        for(int i = 0; i <= segments; i++) {
            float theta = 2.0f * 3.1415926f * (float)i / (float)segments;
            float x = r * cosf(theta);
            float y = r * sinf(theta);
            glVertex2f(cx + x, cy + y);
        }
    glEnd();

    // Restaura o modo 3D
    glPopMatrix(); glMatrixMode(GL_PROJECTION); glPopMatrix();
    glPopAttrib();
    
    return 0;
}
// --- REGISTRO ---
static const struct luaL_Reg astLib[] = {
    {"init", l_init}, {"clear", l_clear}, {"display", l_display}, {"isOpen", l_isOpen},
    {"createBox", l_createBox}, {"setCamera", l_setCamera}, {"isKeyDown", l_isKeyDown},
    {"lockMouse", l_lockMouse}, {"getMouseDelta", l_getMouseDelta}, {"drawText", l_drawText},
    {"loadImage", l_loadImage}, {"drawImageScaled", l_drawImageScaled}, {"getDeltaTime", l_getDeltaTime},
    {"quit", l_quit}, {"wait", l_wait}, {"drawCircle", l_drawCircle}, {NULL, NULL}
};

int luaopen_ast(lua_State *L) { luaL_newlib(L, astLib); return 1; }
