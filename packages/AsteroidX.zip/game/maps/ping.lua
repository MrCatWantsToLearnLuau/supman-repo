local ast = require("ast")

ast.init(1000, 600, "Asteroids Timing: Fixed View")
ast.lockMouse(true)

local game = {
    score = 0, angle = 0, targetAngle = 180,
    targetSize = 15, speed = 200, state = "PLAY"
}

-- FUNÇÃO DE RESET
function resetTarget()
    game.targetAngle = math.random(20, 340)
    game.speed = game.speed + 12
end

-- --- LOOP ---
while ast.isOpen() do
    local dt = ast.getDeltaTime()
    
    if ast.isKeyDown("Escape") then break end

    if game.state == "PLAY" then
        ast.clear(15, 15, 25)

        -- 1. AFASTAMOS A CÂMERA (O segredo está aqui!)
        -- Colocamos a câmera no Z = 500 para ver o plano X/Y de longe
        ast.setCamera(500, 300, 500, 500, 300, 0)

        -- 2. Lógica
        game.angle = (game.angle + game.speed * dt) % 360

        if ast.isKeyDown("Space") then
            local diff = math.abs(game.angle - game.targetAngle)
            if diff > 180 then diff = 360 - diff end

            if diff <= game.targetSize then
                game.score = game.score + 1
                resetTarget()
                ast.wait(150)
            else
                game.state = "DEAD"
            end
        end

        -- 3. RENDER (Tudo no Z = 0)
        local cx, cy = 500, 300
        local radius = 180

        -- Desenha o Anel
        for i = 0, 360, 20 do
            local r = math.rad(i)
            ast.createBox(cx + radius * math.cos(r), cy + radius * math.sin(r), 0, 10, 10, 10, 50, 50, 80)
        end

        -- Alvo (Verde)
        local tr = math.rad(game.targetAngle)
        ast.createBox(cx + radius * math.cos(tr), cy + radius * math.sin(tr), 2, 40, 40, 10, 0, 255, 100)

        -- Indicador que gira (Branco)
        local ar = math.rad(game.angle)
        ast.createBox(cx + radius * math.cos(ar), cy + radius * math.sin(ar), 5, 25, 25, 25, 255, 255, 255)

        ast.drawText("PONTOS: " .. game.score, 20, 20)
    else
        ast.clear(60, 10, 10)
        ast.drawText("ERROU! SCORE: " .. game.score, 380, 250)
        if ast.isKeyDown("R") then
            game.score = 0
            game.speed = 200
            game.state = "PLAY"
            resetTarget()
        end
    end

    ast.display()
    ast.wait(16)
end
ast.quit()
